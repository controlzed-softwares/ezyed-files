# env settings
SERVER_ENV = "SERVER_ENV"

DEBUG = "DEBUG"
SECRET_KEY = "SECRET_KEY"
ALLOWED_HOSTS = "ALLOWED_HOSTS"
CSRF_TRUSTED_ORIGINS = "CSRF_TRUSTED_ORIGINS"

CORS_ALLOWED_ORIGINS = "CORS_ALLOWED_ORIGINS"
CORS_ALLOW_CREDENTIALS = "CORS_ALLOW_CREDENTIALS"
CORS_ALLOW_ALL_ORIGINS = "CORS_ALLOW_ALL_ORIGINS"

DB_NAME = "DB_NAME"
DB_USER = "DB_USER"
DB_PASSWORD = "DB_PASSWORD"
DB_HOST = "DB_HOST"
DB_PORT = "DB_PORT"

REDIS_HOST = "REDIS_HOST"
REDIS_PORT = "REDIS_PORT"

EMAIL_HOST = "EMAIL_HOST"
EMAIL_PORT = "EMAIL_PORT"
EMAIL_USE_TLS = "EMAIL_USE_TLS"
EMAIL_USE_SSL = "EMAIL_USE_SSL"
EMAIL_HOST_USER = "EMAIL_HOST_USER"
EMAIL_HOST_PASSWORD = "EMAIL_HOST_PASSWORD"

ACCESS_TOKEN_LIFETIME_DAYS = "ACCESS_TOKEN_LIFETIME_DAYS"
ACCESS_TOKEN_LIFETIME_SECONDS = "ACCESS_TOKEN_LIFETIME_SECONDS"
ACCESS_TOKEN_LIFETIME_MINUTES = "ACCESS_TOKEN_LIFETIME_MINUTES"
ACCESS_TOKEN_LIFETIME_HOURS = "ACCESS_TOKEN_LIFETIME_HOURS"

REFRESH_TOKEN_LIFETIME_DAYS = "REFRESH_TOKEN_LIFETIME_DAYS"
REFRESH_TOKEN_LIFETIME_SECONDS = "REFRESH_TOKEN_LIFETIME_SECONDS"
REFRESH_TOKEN_LIFETIME_MINUTES = "REFRESH_TOKEN_LIFETIME_MINUTES"
REFRESH_TOKEN_LIFETIME_HOURS = "REFRESH_TOKEN_LIFETIME_HOURS"

SENTRY_ENABLE = "SENTRY_ENABLE"
SENTRY_DSN = "SENTRY_DSN"

AWS_ACCESS_KEY = "AWS_ACCESS_KEY"
AWS_SECRET_KEY = "AWS_SECRET_KEY"
AWS_STORAGE_BUCKET_NAME = "AWS_STORAGE_BUCKET_NAME"
# ===================================================================

# server env
DEVELOPMENT = "development"
STAGING = "staging"
PRODUCTION = "production"
# ===================================================================

# request, response & pagination
AUTHORIZATION = "authorization"
REQUEST = "request"
RESPONSE = "response"
SUCCESS = "success"
ERROR = "error"
MESSAGE = "message"
DATA = "data"
META = "meta"
CODE = "code"

PAGINATE = "paginate"
PAGINATION = "pagination"
DEFAULT_PAGE_SIZE = 10
DEFAULT_PAGE_NUMBER = 1
PAGE_SIZE = "page_size"
PAGE_COUNT = "page_count"
PAGE_NUMBER = "page_number"

INFO = "info"
SEARCH = "search"
DATE = "date"
DATE_RANGE = "date_range"
START_DATE = "start_date"
END_DATE = "end_date"
STATUS = "status"

LIST = "list"
DETAIL = "detail"
ACTION = "action"
QUERY = "query"

QUERYSET = "queryset"
INSTANCE = "instance"
INSTANCES = "instances"
# ===================================================================

# auth
PLATFORM = "platform"
WEB = "web"
ANDROID = "android"
IOS = "ios"

TOKEN = "token"
ACCESS_TOKEN = "access_token"
REFRESH_TOKEN = "refresh_token"
# ===================================================================

# property types
STRING = "string"
INTEGER = "integer"
DECIMAL = "decimal"
URL = "url"
DOMAIN = "domain"
EMAIL = "email"
MOBILE = "mobile"
FILE = "file"
HTML = "html"
# ===================================================================

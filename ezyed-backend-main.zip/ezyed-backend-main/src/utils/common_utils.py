import string
import secrets
import pendulum
from babel import numbers
from num2words import num2words
from nameparser import HumanName

from django.conf import settings
from django.utils.timezone import localtime
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.contrib.auth.tokens import default_token_generator


def get_first_name(name):
    parsed_name = HumanName(name)
    return parsed_name.first


def get_last_name(name):
    parsed_name = HumanName(name)
    return parsed_name.last


def get_name_initials(name):
    parsed_name = HumanName(name, initials_format="{first}{last}")
    return parsed_name.initials().replace(".", "").strip()


def format_number(number, round_precision=0):
    number = round(number, round_precision)
    return numbers.format_number(number, locale="en_IN")


def format_amount(amount):
    return numbers.format_currency(amount, "INR", locale="en_IN")


def amount_to_words(amount):
    return f"{num2words(amount, lang='en_IN')} indian rupees only"


def format_datetime(datetime, format):
    datetime = localtime(datetime)
    dt = pendulum.instance(dt=datetime, tz=settings.TIME_ZONE)
    return dt.format(format)


def generate_random_string(size=6, chars=string.ascii_letters):
    return "".join(secrets.choice(chars) for _ in range(size))


def generate_otp(size):
    return generate_random_string(size=size, chars=string.digits)


def make_token_for_user(user):
    return default_token_generator.make_token(user)


def check_token_for_user(user, token):
    return default_token_generator.check_token(user, token)


def encode_urlsafe_base64(s):
    return urlsafe_base64_encode(force_bytes(s))


def decode_urlsafe_base64(s):
    return urlsafe_base64_decode(s).decode()


def generate_random_username(size=8):
    return generate_random_string(
        size=size,
        chars=string.ascii_uppercase + string.digits,
    )


def generate_username_from_email(email):
    username, _, _ = email.partition("@")
    return username


def generate_avatar_url_from_name(first_name, last_name):
    return f"https://ui-avatars.com/api/?background=f3f4f6&rounded=false&size=512&font-size=0.52&name={first_name}+{last_name}&format=png"

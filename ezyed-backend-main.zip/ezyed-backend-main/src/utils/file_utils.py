import os
import mimetypes


def get_file_name(url, with_ext=False):
    base_name = os.path.basename(url)
    if with_ext:
        return base_name
    filename, _ = os.path.splitext(base_name)
    return filename


def get_file_ext(url):
    base_name = os.path.basename(url)
    _, ext = os.path.splitext(base_name)
    return ext


def get_file_mimetype(url):
    mimetype, _ = mimetypes.guess_type(url, strict=True)
    return mimetype


def is_image(url):
    mimetype = get_file_mimetype(url)
    return mimetype.startswith("image/") if mimetype else False


def is_pdf(url):
    mimetype = get_file_mimetype(url)
    return mimetype.endswith("/pdf") if mimetype else False

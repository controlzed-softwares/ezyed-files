from typing import Sequence
from django.core.mail import EmailMessage


class EmailAttachment:
    def __init__(self, filename, content, mimetype=None):
        self.filename = filename
        self.content = content
        self.mimetype = mimetype


class EmailService:
    """
    Helper class for Email.
    """

    @staticmethod
    def send_email(
        subject: str = "",
        body: str = "",
        to: Sequence[str] = None,
        cc: Sequence[str] = None,
        bcc: Sequence[str] = None,
        reply_to: Sequence[str] = None,
        headers: dict[str, str] = None,
        from_email: str = None,
        attachments: Sequence[EmailAttachment] = None,
    ) -> bool:
        try:
            email = EmailMessage(
                subject=subject,
                body=body,
                to=to,
                cc=cc,
                bcc=bcc,
                reply_to=reply_to,
                headers=headers,
                from_email=from_email,
            )
            email.content_subtype = "html"

            if attachments and len(attachments):
                for attachment in attachments:
                    email.attach(
                        attachment.filename,
                        attachment.content,
                        attachment.mimetype,
                    )

            return bool(email.send(fail_silently=False))
        except Exception as e:
            print("Error in sending email: ", e)
            return False

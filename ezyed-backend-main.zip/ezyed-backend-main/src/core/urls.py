from django.urls import path

from core.views import FileApiView

urlpatterns = [
    path("files/", FileApiView.as_view()),
    path("files/<int:id>/", FileApiView.as_view()),
]

from django.contrib import admin

from core.models import File
from core.forms import AuthenticationForm


@admin.register(File)
class FileStorageAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "file",
        "file_extension",
        "file_mimetype",
        "created_at",
    )


admin.site.login_form = AuthenticationForm

from helpers.views import BaseAPIView, Methods
from rest_framework.permissions import IsAuthenticatedOrReadOnly

from core.models import File
from core.serializers import FileSerializer


class FileApiView(BaseAPIView):
    model_class = File
    serializer_class = FileSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    methods = [Methods.GET, Methods.POST]

from django.db import models

from utils import file_utils
from helpers.models import BaseModel


class File(BaseModel):
    file = models.FileField(max_length=500)

    class Meta:
        verbose_name = "File"
        verbose_name_plural = "Files"

    def __str__(self):
        return self.file.name

    @property
    def file_url(self):
        return self.file.url

    @property
    def file_name(self):
        return file_utils.get_file_name(self.file_url)

    @property
    def file_name_with_ext(self):
        return file_utils.get_file_name(self.file_url, with_ext=True)

    @property
    def file_extension(self):
        return file_utils.get_file_ext(self.file_url)

    @property
    def file_mimetype(self):
        return file_utils.get_file_mimetype(self.file_url)

    @property
    def is_image(self):
        return file_utils.is_image(self.file_url)

    @property
    def is_pdf(self):
        return file_utils.is_pdf(self.file_url)

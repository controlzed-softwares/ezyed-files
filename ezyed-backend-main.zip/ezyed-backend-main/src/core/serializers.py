from rest_framework import serializers

from core.models import File


class FileSerializer(serializers.ModelSerializer):
    class Meta:
        model = File
        fields = (
            "id",
            "file",
            "file_name",
            "file_name_with_ext",
            "file_extension",
            "file_mimetype",
            "is_image",
            "is_pdf",
        )

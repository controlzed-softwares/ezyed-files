from django.core.validators import URLValidator, RegexValidator, EmailValidator


class Validators:
    """
    Data Validators
    """

    @staticmethod
    def email(email):
        try:
            EmailValidator()(email)
            return True
        except:
            return False

    @staticmethod
    def mobile(number):
        try:
            RegexValidator(regex=r"^[0-9]{10}$")(number)
            return True
        except:
            return False

    @staticmethod
    def url(url):
        try:
            URLValidator()(url)
            return True
        except:
            return False

    @staticmethod
    def domain(domain):
        try:
            pattern = (
                r"^(([a-zA-Z]{1})|([a-zA-Z]{1}[a-zA-Z]{1})|"
                r"([a-zA-Z]{1}[0-9]{1})|([0-9]{1}[a-zA-Z]{1})|"
                r"([a-zA-Z0-9][-_.a-zA-Z0-9]{0,61}[a-zA-Z0-9]))\."
                r"([a-zA-Z]{2,13}|[a-zA-Z0-9-]{2,30}.[a-zA-Z]{2,3})$"
            )
            RegexValidator(regex=pattern)(domain)
            return True
        except:
            return False

    def truthy(value):
        value = str(value).lower()
        return value in [True, "true", 1, "1", "on"]

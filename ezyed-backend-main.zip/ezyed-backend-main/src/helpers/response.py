from rest_framework import status
from rest_framework.response import Response

from constants import error_codes
from constants import error_messages


class SuccessResponse(Response):
    def __init__(self, data=None, pagination=None, message=None, **kwargs):
        data = dict(success=True, data=data, message=message, pagination=pagination)
        super().__init__(data, status=status.HTTP_200_OK, **kwargs)


class ErrorResponse(Response):
    def __init__(
        self,
        error=error_messages.INTERNAL_SERVER_ERROR,
        error_code=error_codes.INTERNAL_SERVER_ERROR,
        status=status.HTTP_500_INTERNAL_SERVER_ERROR,
    ):
        data = dict(success=False, error=error, error_code=error_code)
        super().__init__(data, status=status)


class Error400Response(ErrorResponse):
    def __init__(
        self,
        error=error_messages.BAD_REQUEST,
        error_code=error_codes.BAD_REQUEST,
    ):
        super().__init__(
            error=error,
            error_code=error_code,
            status=status.HTTP_400_BAD_REQUEST,
        )


class Error401Response(ErrorResponse):
    def __init__(
        self,
        error=error_messages.UNAUTHORIZED,
        error_code=error_codes.UNAUTHORIZED,
    ):
        super().__init__(
            error=error,
            error_code=error_code,
            status=status.HTTP_401_UNAUTHORIZED,
        )


class Error403Response(ErrorResponse):
    def __init__(
        self,
        error=error_messages.FORBIDDEN,
        error_code=error_codes.FORBIDDEN,
    ):
        super().__init__(
            error=error,
            error_code=error_code,
            status=status.HTTP_403_FORBIDDEN,
        )


class Error404Response(ErrorResponse):
    def __init__(
        self,
        error=error_messages.NOT_FOUND,
        error_code=error_codes.NOT_FOUND,
    ):
        super().__init__(
            error=error,
            error_code=error_code,
            status=status.HTTP_404_NOT_FOUND,
        )

from django.core.paginator import Paginator

from constants import keys
from helpers.validators import Validators


def apply_pagination(request, queryset):
    paginate = request.GET.get(keys.PAGINATE, True)

    if not Validators.truthy(paginate):
        return queryset, None

    page_size = int(request.GET.get(keys.PAGE_SIZE, keys.DEFAULT_PAGE_SIZE))
    paginator = Paginator(queryset, page_size)
    page_count = int(paginator.num_pages)
    page_number = int(request.GET.get(keys.PAGE_NUMBER, keys.DEFAULT_PAGE_NUMBER))
    new_queryset = paginator.get_page(page_number).object_list
    return new_queryset, {
        keys.PAGE_SIZE: page_size,
        keys.PAGE_COUNT: page_count,
        keys.PAGE_NUMBER: page_number,
    }

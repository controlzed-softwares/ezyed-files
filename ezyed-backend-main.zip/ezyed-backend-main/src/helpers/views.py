from enum import Enum
from rest_framework.views import APIView
from django.shortcuts import get_object_or_404
from rest_framework.exceptions import MethodNotAllowed

from helpers import paginator
from helpers.response import SuccessResponse


class Methods(Enum):
    GET = "get"
    POST = "post"
    PATCH = "patch"
    DELETE = "delete"
    ALL = "__all__"


class BaseAPIView(APIView):
    """Base APIView: GET, POST, PATCH, DELETE"""

    model_class = None
    serializer_class = None
    filter_class = None
    methods = [Methods.ALL]
    lookup_field = "id"

    def is_method_allowed(self, method):
        methods = set(self.methods)
        return any(methods.intersection([Methods.ALL, method]))

    def get_object(self, **kwargs):
        return get_object_or_404(self.model_class, **kwargs)

    def get_queryset(self):
        return self.model_class.objects.all()

    def filter_queryset(self, queryset):
        if self.filter_class:
            filterset = self.filter_class(
                self.request.GET,
                queryset=queryset,
                request=self.request,
            )
            if filterset.is_valid():
                queryset = filterset.qs

        return queryset

    def paginate_queryset(self, queryset):
        return paginator.apply_pagination(self.request, queryset)

    def get_serializer_context(self):
        return {"request": self.request}

    def get_serializer(self, *args, **kwargs):
        kwargs.setdefault("context", self.get_serializer_context())
        return self.serializer_class(*args, **kwargs)

    def get(self, request, **kwargs):
        if not self.is_method_allowed(Methods.GET):
            raise MethodNotAllowed(method=Methods.GET.value)

        if self.lookup_field in kwargs.keys():
            obj = self.get_object(**kwargs)
            serializer = self.get_serializer(obj)
            return SuccessResponse(data=serializer.data)

        queryset = self.get_queryset()
        queryset = self.filter_queryset(queryset)
        queryset, pagination = self.paginate_queryset(queryset)
        serializer = self.get_serializer(queryset, many=True)
        return SuccessResponse(data=serializer.data, pagination=pagination)

    def perform_post(self, serializer):
        return serializer.save()

    def post(self, request):
        if not self.is_method_allowed(Methods.POST):
            raise MethodNotAllowed(method=Methods.POST.value)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_post(serializer)
        return SuccessResponse(data=serializer.data, message="Item created")

    def perform_patch(self, serializer):
        return serializer.save()

    def patch(self, request, **kwargs):
        if not self.is_method_allowed(Methods.PATCH):
            raise MethodNotAllowed(method=Methods.PATCH.value)

        obj = self.get_object(**kwargs)
        serializer = self.get_serializer(obj, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        self.perform_patch(serializer)
        return SuccessResponse(data=serializer.data, message="Item updated")

    def perform_delete(self, obj):
        obj.delete()

    def delete(self, request, **kwargs):
        if not self.is_method_allowed(Methods.DELETE):
            raise MethodNotAllowed(method=Methods.DELETE.value)

        obj = self.get_object(**kwargs)
        self.perform_delete(obj)
        return SuccessResponse(message="Item deleted")

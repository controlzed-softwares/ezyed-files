from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.exceptions import ValidationError

from helpers.models import BaseModel


class User(AbstractUser, BaseModel):
    email = models.EmailField(unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "User"
        verbose_name_plural = "Users"

    def __str__(self):
        return self.email

    def clean(self):
        if not self.email:
            raise ValidationError(
                {
                    "email": "Email is required",
                }
            )

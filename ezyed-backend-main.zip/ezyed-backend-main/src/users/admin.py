from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from users.models import User


@admin.register(User)
class UserAdminConfig(UserAdmin):
    list_display = ("id", "email", "is_active")
    list_filter = (
        "is_active",
        "is_staff",
        "is_superuser",
        "created_at",
    )
    ordering = ("created_at",)
    readonly_fields = ("created_at", "updated_at", "last_login")
    search_fields = ("email",)
    fieldsets = (
        (
            "",
            {
                "fields": ("email", "password"),
            },
        ),
        (
            "Access Control",
            {
                "fields": (
                    "is_active",
                    "is_staff",
                    "is_superuser",
                ),
            },
        ),
        (
            "Others",
            {
                "fields": ("created_at", "updated_at", "last_login"),
            },
        ),
    )
    add_fieldsets = (
        (
            "",
            {
                "fields": (
                    "email",
                    "password1",
                    "password2",
                )
            },
        ),
        (
            "Access Control",
            {
                "fields": (
                    "is_staff",
                    "is_superuser",
                ),
            },
        ),
    )

    def get_queryset(self, request):
        self.request = request
        qs = super(UserAdminConfig, self).get_queryset(request)
        if not request.user.is_superuser:
            return qs.exclude(is_superuser=True)
        return qs

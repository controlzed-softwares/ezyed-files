from django.dispatch import receiver
from django.db.models.signals import pre_save, post_save

from utils.common_utils import generate_username_from_email
from users.models import User


@receiver(pre_save, sender=User)
def user_pre_save(sender, instance, **kwargs):
    if not instance.id:
        # generate and set username
        if not instance.username:
            instance.username = generate_username_from_email(instance.email)

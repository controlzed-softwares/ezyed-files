# EzyEd : backend
API Backend service for `EzyEd` project.

## Technology Used:
- Python
- Django
- Postgres
- Docker


## Setup : Local
### Requirements: 
- Python `3.12` 
- [Poetry](https://python-poetry.org/)
- [Docker](https://www.docker.com/products/docker-desktop/)
- [GNU Make](https://www.gnu.org/software/make/)


### Creating virtual environment
```bash
poetry run python -m venv .venv
```

### Installing dependencies
```bash
poetry install
```

### Starting the local server
```bash
make start
```
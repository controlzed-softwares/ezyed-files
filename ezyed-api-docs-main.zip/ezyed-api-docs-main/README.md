# EzyEd : api-docs
API documentation for `EzyEd` project.

## Requirements: 
- [Bruno](https://www.usebruno.com/downloads)

## Setup
- Download and install `bruno` client on your system
- Clone this repo. 
- Open `bruno` client
- On the homepage click on `Open Collection` and select the cloned repo.
- Open the repo. in any text editor and create a .env file with the content of .env.sample
